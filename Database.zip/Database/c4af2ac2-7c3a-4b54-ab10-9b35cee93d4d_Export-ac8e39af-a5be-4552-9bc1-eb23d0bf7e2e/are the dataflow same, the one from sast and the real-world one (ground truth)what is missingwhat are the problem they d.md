1. are the dataflow same, the one from sast and the real-world one (ground truth,coverage)
2. what is missing, what are the problem they did not capture, compare (visibility)
3. why they are causing fp/fn (missing)
4. try to fix

